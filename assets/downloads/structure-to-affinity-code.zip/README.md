# Structure to Affinity

Deven Shah

Predicting human GSK-3β binding affinity from molecular descriptors and Morgan fingerprints.

## Contents

- `structure_to_affinity.ipynb`: analysis notebook with saved outputs.
- `data/raw/`: frozen BindingDB data and query pages.
- `requirements.txt`: original dependency versions.

## Run

Extract this archive, install the dependencies in a Python environment, and open the notebook from the extracted folder in JupyterLab. The original analysis used Python 3.12.13.

```sh
python -m pip install -r requirements.txt
python -m jupyter lab structure_to_affinity.ipynb
```

The notebook documents data provenance, licensing references, validation, and limitations. Results are for a small, heterogeneous dataset and do not establish clinical or experimental utility.
